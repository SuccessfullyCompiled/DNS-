#ifndef KEYGEN_H
#define KEYGEN_H
#include "base.h"

class RsaKeyGen
{
 public:
  static void Generate_RSA(string privatefile, string publicfile, int nbits);
  static void GenerateStrongPrime(mpz_t * Q, mpz_t * q, int nbits);
  static void GenerateNextPrime(mpz_t * nextprime, mpz_t * pos);
};

#endif
