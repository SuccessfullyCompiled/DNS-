#ifndef UDP_PACKET_H
#define UDP_PACKET_H

class UdpPacket
{
 protected:
  unsigned short m_type;					/* 1: request, 2: response key 3: response data*/
 public:
  unsigned short& Type(){ return m_type; }
};

#endif
