#ifndef CRYPTO_TOOL_H
#define CRYPTO_TOOL_H

#include "base.h"
#include <openssl/sha.h>
#include <openssl/rc4.h>
#include <openssl/aes.h>

class CryptoTool
{
 public:
  static string Hash(const char * input, size_t len);
  static string Hash(const string& input);
  static string Hash(const mpz_t * input);
  static string FDH(const string& input, mpz_t * modulus);
  static void FDH(mpz_t * mpzhash, const string& input, mpz_t * modulus);
  static string HTag(const string& input);
  static string HKey(const string& input);
  static string HIndKey(const string& input);
  static string AES_ECB_Encrypt(const string& input, const string& key);
  static string AES_ECB_Decrypt(const string& input, const string& key);
  static string AES_CBC_Encrypt(const string& input, const string& key);
  static string AES_CBC_Decrypt(const string& input, const string& key);
  static void RC4(char * output, const char* input, const size_t datalen, const string& key);
  static string RC4(const string& input, const string& key);
  static string RC4(const string& input, const mpz_t * key);
  static string XOR(const string& input, const string& key);
};

#endif
