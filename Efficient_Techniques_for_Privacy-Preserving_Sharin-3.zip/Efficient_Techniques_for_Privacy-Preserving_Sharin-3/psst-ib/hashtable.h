#ifndef HASH_TABLE_H
#define HASH_TABLE_H

struct entry
{
  mpz_t * mpzHashKi;            /* the last 30 bits serve as the key into the hash table */
  string strEncK_Ki;
  //  string strEncInd;					/* encrypted file index */
  int index;
  //  unsigned int fileindex;           /* enough to hold 100,000 */
  struct entry *next;
};

class HashTable 
{
 private:
  unsigned int m_uiTableLength;
  struct entry ** m_pTable;
  mpz_t * m_mpzMask;
  unsigned int m_uiCollisions;
  unsigned int m_uiTotal;
 public:
  void Create(unsigned int bits);
  int Insert(mpz_t * mpzHashKi, string strEncK_Ki, int index);
  struct entry* Lookup(const struct entry* ie, mpz_t * mpzHashKi);
  struct entry* Lookup(const struct entry* ie, string strHashKi);
  unsigned int CollisionNum() { return m_uiCollisions; }
  unsigned int TotalNum() { return m_uiTotal; }
  unsigned int m_uiSize;
};


#endif
