#ifndef CLIENTPROTOCOL_WRAPPER
#define CLIENTPROTOCOL_WRAPPER

class ServerProtocolWrapper
{
 public:

  virtual int Start() = 0;

};

#endif
