#ifndef IB_PROTOCOL_H
#define IB_PROTOCOL_H

#include "base.h"

class IBProtocol
{
 public:
  virtual int Setup(string foldername) = 0;

  virtual int PreCompute() = 0;

  virtual int OnRequest(vector<string >& output, const vector<string >& input) = 0;
};

#endif
