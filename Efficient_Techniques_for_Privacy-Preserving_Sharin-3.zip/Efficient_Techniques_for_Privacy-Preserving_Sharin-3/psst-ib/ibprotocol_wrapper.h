#ifndef CLIENTPROTOCOL_WRAPPER
#define CLIENTPROTOCOL_WRAPPER

class IBProtocolWrapper
{
 public:

  virtual int Start() = 0;

};

#endif
