#ifndef BASIC_TOOL_H
#define BASIC_TOOL_H

#include "base.h"
#include "pbc/pbc.h"

class BasicTool
{
 public:
  static int Load_File(string& str, string filename);
  static int Load_File(char* & buffer, size_t& len, string filename);
  static int Dump_File(const string& str, string filename);
  static string Strip(const string& str, char dem);
  static int Load_RSA_Priv_Key(mpz_t * d, mpz_t * N, string filename);
  static int Load_RSA_Pub_Key(mpz_t * e, mpz_t * N, mpz_t * g, string filename);
  static int Load_DSA_Priv_Key(mpz_t * p, mpz_t *q, mpz_t *g, mpz_t *x, string filename);
  static int Load_DSA_Pub_Key(mpz_t * p, mpz_t *q, mpz_t *g, mpz_t *y, string filename);
  static int Load_IBE_Server_Key(pairing_t *pairing, element_t *P, element_t *Q, element_t *z, element_t *R, string filename);
  static int Load_IBE_Client_Key(pairing_t *pairing, element_t *P, element_t *Q, element_t *s, string filename);
  static void TimeStamp(unsigned long& milli);
  static string TimeStamp();
  static double F_Time(int s);
  static string ToLowercase(string& str);
  static void lTrim(string& s, string dem);
  static void rTrim(string& s, string dem);
 public:
  static const int START = 0;
  static const int STOP = 1;
};

#endif
