#ifndef BASE_H
#define BASE_H

#include <vector>
#include <queue>
#include <deque>
#include <map>
#include <list>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cctype>
#include <algorithm>
using namespace std;

#include <gmp.h>
#include <arpa/inet.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define MAX_RANDOM_NUM 1000
#define SERVER_PORT 6666
#define IB_PORT 7777
#define BLOCK_LEN 1024
#define SIG_LEN 2048/8
#define HASH_LEN 160/8
#define MAX_BLOCK_SIZE 128/8
#define HASH_BITS_LEN 160
#define NO_LOAD_FILE
#define MAX_BUF 100000000
//#define _DEBUG
#endif
