#ifndef MEMREUSE_H
#define MEMREUSE_H

#include <gmp.h>
#include <pbc/pbc.h>
#include "base.h"
#include "udpresponse.h"
#include "udprequest.h"

class Memreuse
{
 public:
  static void Initialize(unsigned long size, unsigned long nbits);
  static void InitializeElements(unsigned long size, pairing_t * pairing);
  static void InitializeBlocks(unsigned long size);
  static void InitializeRecords(unsigned long size);
  static mpz_t * New();
  static Record * NewRecord();
  static UdpBlock * NewBlock();
  static size_t RecordSize()
  {
    return m_qrecord.size();
  }
  static size_t BlockSize()
  {
	return m_qblock.size();
  }
  static element_t * NewElement();
  static element_t * NewG1Element();
  static element_t * NewG2Element();
  static element_t * NewGTElement();
  static element_t * NewZrElement();
  static void DeleteG1Element(element_t*& element);
  static void DeleteG2Element(element_t*& element);
  static void DeleteGTElement(element_t*& element);
  static void DeleteZrElement(element_t*& element);
  static void Delete(mpz_t*& mpz);
  static void Delete(UdpBlock*& pblock);
  static void Delete(Record*& precord);
 protected:
  static queue<mpz_t* > m_qmpz;
  static queue<element_t* > m_qG1Element;
  static queue<element_t* > m_qG2Element;
  static queue<element_t* > m_qGTElement;
  static queue<element_t* > m_qZrElement;
  static queue<Record *> m_qrecord;
  static queue<UdpBlock *> m_qblock;
  static unsigned long m_nbits;
  static pairing_t * m_pairing;
};

#endif
