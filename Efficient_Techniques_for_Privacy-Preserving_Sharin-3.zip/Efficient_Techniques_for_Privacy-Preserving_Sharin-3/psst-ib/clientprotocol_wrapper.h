#ifndef SERVERPROTOCOL_WRAPPER
#define SERVERPROTOCOL_WRAPPER


class ClientProtocolWrapper
{
 public:

  virtual int Start() = 0;

};

#endif
