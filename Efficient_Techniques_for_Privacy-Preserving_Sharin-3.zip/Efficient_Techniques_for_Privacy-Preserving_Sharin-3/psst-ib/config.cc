#include "config.h"
#include "base.h"
#include <stdio.h>
#include <stdlib.h>

string Config::m_authenserver_ip = "";
unsigned short Config::m_authenserver_port = 0;
string Config::m_ib_ip = "";
string Config::m_client_ip = "";
unsigned short Config::m_ib_port = 0;
unsigned short Config::m_client_port = 0;
string Config::m_key_dir = "";
bool Config::m_output_binaryfile = true;
string Config::m_original_database = "";
string Config::m_original_database_dir = "";
string Config::m_output_database_dir = "";
string Config::m_database_format = "";
string Config::m_transport = "";
size_t Config::m_num_elements = 0;
int Config::m_udp_block_size = 512;
string Config::m_enc_mode = "";
int Config::m_HashTableSizeInBits = 0;
int Config::m_num_decrypt_thread = 1;
int Config::m_sliding_window = 0;
string Config::m_signature_protocol = "";

int Config::Input(string filename)
{
  char buf[256];
  ifstream infile(filename.c_str());
  if (!infile)
	{
	  cerr<<"open "<<filename<<" failed"<<endl;
	  return 1;
	}
  char token[] = " =\t";
  while (infile.getline(buf, 256))
	{
	  if (strcmp (buf, "") == 0) // blank line
		continue;
      if (buf[0] == '#')        // comment line
        continue;
	  char * beforecomment = strtok(buf, "#");
	  char * field = strtok (beforecomment, token);
	  char * value = strtok (NULL, token);	  
	  if (strcmp (field, "authenserver_ip") == 0)
		{
		  Config::m_authenserver_ip = value;
		}
	  else if (strcmp (field, "authenserver_port") == 0)
		{
		  Config::m_authenserver_port = atoi(value);
		}
	  else if (strcmp (field, "ib_ip") == 0)
		{
		  Config::m_ib_ip = value;
		}
	  else if (strcmp (field, "ib_port") == 0)
		{
		  Config::m_ib_port = atoi(value);
		}
	  else if (strcmp (field, "client_ip") == 0)
		{
		  Config::m_client_ip = value;
		}
	  else if (strcmp (field, "client_port") == 0)
		{
		  Config::m_client_port = atoi(value);
		}
	  else if (strcmp (field, "key_dir") == 0)
		{
		  Config::m_key_dir = value;
		  if (Config::m_key_dir[m_key_dir.length()-1] != '/')
			{
			  Config::m_key_dir += '/';
			}
		}
	  else if (strcmp (field, "original_database") == 0)
		{
		  Config::m_original_database = value;
		  Config::m_original_database_dir = 
			Config::m_original_database.substr(0, Config::m_original_database.rfind('/')+1);
		  ifstream infile (Config::m_original_database.c_str());
		  string t;
		  while (getline(infile, t))
			{
			  Config::m_num_elements ++;
			}
		  infile.close();
		}
	  else if (strcmp (field, "output_database_dir") == 0)
		{
		  Config::m_output_database_dir = value;
		  if (Config::m_output_database_dir[m_output_database_dir.length()-1] != '/')
			{
			  Config::m_output_database_dir += '/';
			}
		}
	  else if (strcmp (field, "output_binaryfile") == 0)
		{
		  if (strcmp (value, "no") == 0)
			Config::m_output_binaryfile = false;
		  else
			Config::m_output_binaryfile = true;
		}
	  else if (strcmp (field, "databaseformat") == 0)
		{
		  Config::m_database_format = value;
		}
	  else if (strcmp (field, "transport") == 0)
		{
		  Config::m_transport = value;
		}
	  else if (strcmp (field, "udp_block_size") == 0)
		{
		  Config::m_udp_block_size = atoi(value);
		}
	  else if (strcmp (field, "enc_mode") == 0)
		{
		  Config::m_enc_mode = value;
		}
	  else if (strcmp (field, "hashtable_size") == 0)
		{
		  Config::m_HashTableSizeInBits = atoi(value);
		}
	  else if (strcmp (field, "num_decrypt_thread") == 0)
		{
		  Config::m_num_decrypt_thread = atoi(value);
		}
	  else if (strcmp (field, "sliding_window") == 0)
		{
		  Config::m_sliding_window = atoi(value);
		}
	  else if (strcmp (field, "signature_protocol") == 0)
		{
		  Config::m_signature_protocol = value;
		}
	}
  return 0;
}


void Config::Print()
{
  cout<<"server ip: "<<m_authenserver_ip<<endl;
  cout<<"server port: "<<m_authenserver_port<<endl;
  cout<<"ib ip: "<<m_ib_ip<<endl;
  cout<<"ib port: "<<m_ib_port<<endl;
  cout<<"key dir: "<<m_key_dir<<endl;
  cout<<"output_binaryfile: "<<m_output_binaryfile<<endl;
}

