#include "rsakeygen.h"

int main()
{
  RsaKeyGen ckeygen;
  ckeygen.Generate_RSA("rsa.priv", "rsa.pub", 1024);
  return 0;
}
