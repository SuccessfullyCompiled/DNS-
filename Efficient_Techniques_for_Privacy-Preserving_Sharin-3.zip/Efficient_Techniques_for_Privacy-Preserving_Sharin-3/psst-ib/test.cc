#include "base.h"
#include "mpz_tool.h"
#include "basic_tool.h"
#include "config.h"
#include "crypto_tool.h"
vector<string> vecTags;
int main()
{
  string strSig = "Test Speed and Confirm";
  strSig = CryptoTool::Hash(strSig);
  string hstrSigCounter;
  hstrSigCounter.reserve(24);
  BasicTool::F_Time(BasicTool::START);
  for (int i = 0; i < 10000; i++)
    {
      hstrSigCounter.clear();
      hstrSigCounter.append(strSig);
      hstrSigCounter.append((const char *)&i, sizeof(int));
      string strTag = CryptoTool::HTag(hstrSigCounter);
      if (i == 2)
        cout<<strTag<<endl;
      vecTags.push_back(strTag);
    }
  cout<<BasicTool::F_Time(BasicTool::STOP)<<endl;


  stringstream ss;
  vecTags.clear();
  BasicTool::F_Time(BasicTool::START);
  for (int i = 0; i < 10000; i++)
    {
      ss.str("");
      ss<<strSig<<i;
      string strTag = CryptoTool::HTag(ss.str());
      vecTags.push_back(strTag);
    }
  cout<<BasicTool::F_Time(BasicTool::STOP)<<endl;

  char str[24];
  string hstr;
  vecTags.clear();
  memcpy(str, strSig.c_str(), strSig.size());
  BasicTool::F_Time(BasicTool::START);
  for (int i = 0; i < 10000; i++)
    {
      memcpy(str+HASH_LEN, (char *)&i, sizeof(int));
      hstr.assign(str, 24);
      string strTag = CryptoTool::HTag(hstr);
      if (i == 2)
        cout<<strTag<<endl;
      vecTags.push_back(strTag);
    }
  cout<<BasicTool::F_Time(BasicTool::STOP)<<endl;


  // encrypt speed
  vecTags.clear();
  BasicTool::F_Time(BasicTool::START);
  for (int i = 0; i < 10000; i++)
    {
      memcpy(str, strSig.c_str(), strSig.size());
      memcpy(str+16, (char *)&i, sizeof(int));
      hstr.assign(str, 20);
      string strTag = CryptoTool::HTag(hstr);

      string p = CryptoTool::XOR(strTag.substr(0, 16), strTag.substr(0, 16));
      vecTags.push_back(p);
    }
  cout<<"xor: "<<BasicTool::F_Time(BasicTool::STOP)<<endl;
  
  // encrypt speed
  vecTags.clear();
  BasicTool::F_Time(BasicTool::START);
  for (int i = 0; i < 10000; i++)
    {
      memcpy(str, strSig.c_str(), strSig.size());
      memcpy(str+16, (char *)&i, sizeof(int));
      hstr.assign(str, 20);
      string strTag = CryptoTool::HTag(hstr);

      string p = CryptoTool::AES_CBC_Decrypt(strTag.substr(0, 16), strTag.substr(0, 16));
      vecTags.push_back(p);
    }
  cout<<"AES: "<<BasicTool::F_Time(BasicTool::STOP)<<endl;

  // encrypt speed
  vecTags.clear();
  BasicTool::F_Time(BasicTool::START);
  for (int i = 0; i < 10000; i++)
    {
      memcpy(str, strSig.c_str(), strSig.size());
      memcpy(str+16, (char *)&i, sizeof(int));
      hstr.assign(str, 20);
      string strTag = CryptoTool::HTag(hstr);

      string p = CryptoTool::RC4(strTag.substr(0, 16), strTag.substr(0, 16));
      vecTags.push_back(p);
    }
  cout<<"RC4: "<<BasicTool::F_Time(BasicTool::STOP)<<endl;

}
