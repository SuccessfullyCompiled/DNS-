#ifndef CONFIG_H
#define CONFIG_H

#include "base.h"

class Config
{
 public:
  static int    Input(string filename);
  static void   Print();
 public:
  static string m_authenserver_ip;
  static unsigned short m_authenserver_port;
  
  static string m_ib_ip;
  static unsigned short m_ib_port;
  static string m_client_ip;
  static unsigned short m_client_port;

  static string m_key_dir;
  static string m_output_database_dir;
  static string m_original_database;
  static string m_original_database_dir;

  static bool m_output_binaryfile;
  static string m_database_format;
  static size_t m_num_elements;
  
  static string m_transport;
  static int m_udp_block_size;
  static string m_enc_mode;

  static int m_HashTableSizeInBits;
  static int m_num_decrypt_thread;

  static int m_sliding_window;
  static string m_signature_protocol;
};


#endif
