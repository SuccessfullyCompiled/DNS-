#ifndef UDPAGENT_H
#define UDPAGENT_H
#include "base.h"
#include <sys/socket.h>

class UdpAgent
{
 public:
  UdpAgent();
  UdpAgent(int cs);
  virtual ~UdpAgent();
  virtual void SetNonBlocking();

  virtual int Bind(const unsigned short port);

  virtual int Bind(const string ip, const unsigned short port);

  virtual int Connect(const string& ipaddress, const unsigned short port);

  virtual int Connect(const struct sockaddr_in& address);

  /* for connected one, provide null for target address */
  virtual int SendTo(const char * buf, const unsigned long length, 
		     const string& ipaddress, const unsigned short port);

  virtual int SendTo(const string& buf, const string& ipaddress,
		     const unsigned short port);

  virtual int SendTo(const char * buf, const unsigned long length, 
		     const struct sockaddr_in& hostaddr);

  virtual int SendTo(const string& buf, const struct sockaddr_in& hostaddr);

  virtual int RecvFrom(char * ptr, const unsigned long length, struct sockaddr_in& from);

  virtual int RecvFrom(string& buf, struct sockaddr_in& from);

  virtual int Send(const char * buf, size_t len);
  
  virtual int Recv(char * buf, size_t len);

  virtual int IsReadable(int nusec);

 protected:
  bool m_bConnected;
  int m_socket;
  char m_buf[MAX_BUF];
};

#endif
