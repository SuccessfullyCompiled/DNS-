#ifndef RSA_SERVER_UDP_WRAPPER_H
#define RSA_SERVER_UDP_WRAPPER_H
#include "server.h"
#include "serverprotocol_wrapper.h"
#include "udpagent.h"

class ServerUdpWrapper: public ServerProtocolWrapper
{
 public:
  ServerUdpWrapper();
  ~ServerUdpWrapper();
  virtual int Start();
 protected:
  UdpAgent * m_pUdpAgent;
  Server * m_pServer;
};

#endif
