#ifndef RSA_IB_WRAPPER
#define RSA_IB_WRAPPER
#include "ibprotocol_wrapper.h"
#include "udpagent.h"
#include "hashtable.h"
#include "udprequest.h"
#include "udpresponse.h"
#include "ib.h"

struct window_struct
{
  window_struct(int rid, unsigned short bid)
  {
	respid = rid;
	blockid = bid;
  }
  int respid;
  unsigned short blockid;
};

struct Arg
{
  IB * pIB;
  UdpRequest * pRequest;
};



class IBUdpWrapper: public IBProtocolWrapper
{
 public:
  IBUdpWrapper();
  ~IBUdpWrapper();
  virtual int Setup();
  virtual int Start();
 protected:
  UdpAgent * m_pUdpAgent;
  HashTable m_HashTable;
/*   list<UdpResponse *> m_listSlidingWindow; */
/*   pthread_mutex_t m_mutexSlidingWindow; */
/*   pthread_cond_t m_cvSlidingWindow; */
};

#endif
