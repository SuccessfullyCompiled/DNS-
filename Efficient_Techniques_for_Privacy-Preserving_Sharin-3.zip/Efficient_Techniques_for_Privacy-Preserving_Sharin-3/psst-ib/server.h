#ifndef RSAPPIT_SERVER_H
#define RSAPPIT_SERVER_H
#include "base.h"
#include "pbc/pbc.h"

class Server
{
 public:
  Server();
  ~Server();
  virtual int Setup();
  virtual int PreCompute();

  virtual int OnRequest(char * output, size_t& outLen, const size_t capacity, const char * input, const size_t inLen);
 public:
  mpz_t * m_d;
  mpz_t * m_N;
  mpz_t * m_p;
  mpz_t * m_q;
  mpz_t * m_g;
  mpz_t * m_x;

  element_t * m_emtP;
  element_t * m_emtQ;
  element_t * m_emtz;
  element_t * m_emtR;
  pairing_t * m_pairing;
};


#endif
