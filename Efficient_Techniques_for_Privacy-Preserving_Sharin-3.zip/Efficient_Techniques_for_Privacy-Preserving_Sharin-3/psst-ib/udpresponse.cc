#include "udpresponse.h"

void UdpResponse::SetBlock(const char * buf, unsigned short len)
{
  memcpy(m_block, buf, len < BLOCK_LEN ? len : BLOCK_LEN);
  m_usBlockLength = len < BLOCK_LEN ? len : BLOCK_LEN;
}

bool UdpResponse::IsEmptyResponse()
{
  return (m_iTotalBlocks == 0);
}

