#ifndef UDP_REQUEST_H
#define UDP_REQUEST_H
#include "udppacket.h"
#include "base.h"

class UdpRequest: public UdpPacket
{
 protected:
  unsigned short m_usRequestId;
  int m_iSubRequestId;			/* -1 means transfer every answer, otherwise transfer ith answer */
  int m_iBlockId;
  int m_iTagId;					/* increasing from 0 */
  int m_iLimit;
  char m_Tag[HASH_LEN];
  //  char m_IndKi[HASH_LEN];
 public:
  UdpRequest()
	{
	  m_type = 1;
      m_iTagId = 0;
	}
  unsigned short& RequestId()
  {
	return m_usRequestId;
  }
  int& SubRequestId()
  {
	return m_iSubRequestId;
  }
  int& BlockId()
  {
	return m_iBlockId;
  }
  int& TagId()
  {
	return m_iTagId;
  }
  int& Limit()
  {
	return m_iLimit;
  }
  void SetTag(string strHashKi)
  {
	assert(strHashKi.length() == HASH_LEN);
	memcpy(m_Tag, strHashKi.c_str(), HASH_LEN);
  }
/*   void SetIndKey(string strK) */
/*   { */
/* 	assert(strK.length() == HASH_LEN); */
/* 	memcpy(m_IndKi, strK.c_str(), HASH_LEN); */
/*   } */
  const char * GetTag() const
  {
	return m_Tag;
  }
/*   const char * GetIndKey() const */
/*   { */
/* 	return m_IndKi; */
/*   } */
};

class UdpAck: public UdpPacket
{
  int m_id;
  unsigned long long m_capacity;
  int m_iTagId;					/* increasing from 0 */
  char m_Tag[HASH_LEN];
  char m_IndKi[HASH_LEN];
 public:
 UdpAck(): m_iTagId(0){}
  int & ID()
  {
    return m_id;
  }
  unsigned long long & Capacity()
  {
    return m_capacity;
  }
  int& TagId()
  {
	return m_iTagId;
  }
  void SetTag(string strHashKi)
  {
	assert(strHashKi.length() == HASH_LEN);
	memcpy(m_Tag, strHashKi.c_str(), HASH_LEN);
  }
  void SetIndKey(string strK)
  {
	assert(strK.length() == HASH_LEN);
	memcpy(m_IndKi, strK.c_str(), HASH_LEN);
  }

  const char * GetTag() const
  {
	return m_Tag;
  }
  const char * GetIndKey() const
  {
	return m_IndKi;
  }
};

class UdpSigRequest: public UdpPacket
{
 protected:
  unsigned short m_usRequestId;
  unsigned short m_usSubRequestId;
  unsigned short m_usSigLength;
  char m_sig[SIG_LEN];			/* 512 */
 public:
  UdpSigRequest()
	{
	  m_type = 10;
	}
  unsigned short& RequestId()
  {
	return m_usRequestId;
  }
  unsigned short& SubRequestId()
  {
    return m_usSubRequestId;
  }
  unsigned short& SigLength()
  {
	return m_usSigLength;
  }
  void SetSig(string sig)
  {
	memcpy(m_sig, sig.c_str(), sig.length());
	m_usSigLength = sig.length();
  }
  char * GetSig()
  {
	return m_sig;
  }
};

class UdpSigResponse: public UdpSigRequest
{
 public:
  UdpSigResponse()
	{
	  m_type = 11;
	}
};


#endif
