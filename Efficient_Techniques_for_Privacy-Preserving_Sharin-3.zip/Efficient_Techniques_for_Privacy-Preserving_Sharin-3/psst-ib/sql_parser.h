#ifndef SQL_PARSER_H
#define SQL_PARSER_H

#include "base.h"
#include "basic_tool.h"

class SQLParser
{
 public:
  static void Parse(const string& commandline, string& command, map<string, string>& args);
};

#endif
