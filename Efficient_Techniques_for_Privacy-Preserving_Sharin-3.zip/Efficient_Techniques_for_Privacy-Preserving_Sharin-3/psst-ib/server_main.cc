#include "base.h"
#include "memreuse.h"
#include "config.h"
#include "server_udp_wrapper.h"

int main(int argc, const char * argv[])
{
  string configfilename = "config.ini";

  if (argc == 3 && strcmp(argv[1], "-c") == 0)
    {
      configfilename = argv[2];
    }
  Config::Input(configfilename);

  Memreuse::Initialize(1000, 1024);

  ServerUdpWrapper server;
  server.Start();
  return 0;
}
