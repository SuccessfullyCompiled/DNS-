#ifndef CLIENT_PROTOCOL_H
#define CLIENT_PROTOCOL_H
#include "base.h"

class ClientProtocol
{
 public:
  ///
  virtual int Setup() = 0;

  virtual int PreCompute() = 0;

};

#endif
