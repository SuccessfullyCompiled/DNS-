#include "base.h"
#include "client_udp_wrapper.h"
#include "config.h"

int main(int argc, const char * argv[])
{
  string configfilename = "config.ini";

  if (argc == 3 && strcmp(argv[1], "-c") == 0)
    {
      configfilename = argv[2];
    }
  Config::Input(configfilename);

  Memreuse::Initialize(1000, 1024);
  Memreuse::InitializeBlocks(4000);
  Memreuse::InitializeRecords(64);
  ClientUdpWrapper * client = new ClientUdpWrapper;

  client->ConnectServer(Config::m_authenserver_ip, Config::m_authenserver_port);
  client->ConnectIB(Config::m_ib_ip, Config::m_ib_port);
  client->Start();
  delete client;
  return 0;
}
