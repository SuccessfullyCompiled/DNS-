#ifndef TEST_SERVER_H
#define TEST_SERVER_H

#include "server.h"

class TestServer: public Server
{
 public:
  TestServer();
  /* the first round of request from client, input contains the request content */
  virtual int OnRequest1(const vector<string>& input);
  /* the second round of request from client, input contains the request content */
  virtual int OnRequest2(const vector<string>& input);  
  /* the first round response from the server, output contains the response content */
  virtual int Response1(vector<string>& output);
  /* the second round response from the server, output contains the response content */
  virtual int Response2(vector<string>& output);
};

#endif
