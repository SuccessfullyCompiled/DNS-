#include "test_client.h"

TestClient::TestClient()
{
  m_iNumIterations = 2;
}

void TestClient::Initialize()
{

}

int TestClient::Request1(vector<string>& output)
{
  cout<<"Issuing Request#1 to server"<<endl;
  return 0;
}

int TestClient::Request2(vector<string>& output)
{
  cout<<"Issuing Request#2 to server"<<endl;
  return 0;
}

int TestClient::OnResponse1(const vector<string>& input)
{
  cout<<"Receiving response#1 from server"<<endl;
  return 0;
}

int TestClient::OnResponse2(const vector<string>& input)
{
  cout<<"Receiving response#2 from server"<<endl;
  return 0;
}
