#include "test_server.h"

TestServer::TestServer()
{
  m_iNumIterations = 2;
}

int TestServer::OnRequest1(const vector<string>& input)
{
  cout<<"Receiving request#1 from client"<<endl;
  return 0;
}

int TestServer::OnRequest2(const vector<string>& input)
{
  cout<<"Receiving request#2 from client"<<endl;
  return 0;
}

int TestServer::Response1(vector<string>& output)
{
  cout<<"Issuing Response#1 to the client"<<endl;
  return 0;
}

int TestServer::Response2(vector<string>& output)
{
  cout<<"Issuing Response#2 to the client"<<endl;
  return 0;
}
