/* ---------------------------------------------------------------------
 *
 * -- Privacy-preserving Sharing of Sensitive information Toolkit (PSST)
 *    (C) Copyright 2010 All Rights Reserved
 *
 * -- PSST routines -- Version 1.0.1 -- April, 2010
 * BRSA corresponds to protocol DT10-2 in the paper
 *
 * Author         : Yanbin Lu
 * Security and Privacy Research Outfit (SPROUT),
 * University of California, Irvine
 *
 * -- Bug report: send email to yanbinl@uci.edu
 * ---------------------------------------------------------------------
 *
 * -- Copyright notice and Licensing terms:
 *
 *  Redistribution  and  use in  source and binary forms, with or without
 *  modification, are  permitted provided  that the following  conditions
 *  are met:
 *
 * 1. Redistributions  of  source  code  must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce  the above copyright
 *    notice,  this list of conditions, and the  following disclaimer in
 *    the documentation and/or other materials provided with the distri-
 *    bution.
 * 3. The name of the University,  the SPROUT group,  or the names of its
 *    authors  may not be used to endorse or promote products deri-
 *    ved from this software without specific written permission.
 *
 * -- Disclaimer:
 *
 * THIS  SOFTWARE  IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,  INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE UNIVERSITY
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,  INDIRECT, INCIDENTAL, SPE-
 * CIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO,  PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEO-
 * RY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT  (IN-
 * CLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include "brsa_psi_client.h"
#include "crypto_tool.h"
#include "basic_tool.h"
#include "mpz_tool.h"

BRSA_PSI_Client::BRSA_PSI_Client()
{
  m_g = Memreuse::New();
  m_n = Memreuse::New();
  m_e = Memreuse::New();
  m_Rc = Memreuse::New();
}

void BRSA_PSI_Client::LoadData()
{
  m_set.clear();
  m_rawset.clear();

  ifstream infile(m_strInputFile.c_str());
  if (!infile)
	{
	  cerr<<"open "<<m_strInputFile<<" error"<<endl;
	  return;
	}
  string element;
  while (getline(infile, element) && infile.good())
	{
	  m_rawset.push_back(element);
	  mpz_t * e = Memreuse::New();
	  CryptoTool::FDH(e, element, m_n);
	  m_set.push_back(e);
	}
}

// for preset parameters 
void BRSA_PSI_Client::Setup(int nbits)
{

  stringstream keyfile;
  keyfile.str("");
  keyfile<<"rsa."<<nbits<<".pub";
  BasicTool::Load_RSA_Pub_Key(keyfile.str(), m_e, m_n, m_g);
  LoadData();
  rn.Initialize(nbits);
}


void BRSA_PSI_Client::Initialize(int nbits)
{
  for (size_t i = 0; i < m_set.size(); i++)
    {
      mpz_t * y = Memreuse::New();
      mpz_t * r = Memreuse::New();
      rn.Get_Z_Range(r, m_n);
      mpz_powm(*y, *r, *m_e, *m_n);
	  m_vecRe.push_back(y);
      mpz_invert(*r, *r, *m_n);
      m_vecRinv.push_back(r);

    }
}

void BRSA_PSI_Client::StoreData(const vector<string>& input)
{
  if (m_adaptive)
	{
	  m_data = input;
	}
}

int BRSA_PSI_Client::Request1(vector<string>& output)
{
  mpz_t * hc = Memreuse::New();
  for (size_t i = 0; i < m_set.size(); i++)
    {
      mpz_mul(*hc, *m_vecRe[i], *m_set[i]);
      mpz_mod(*hc, *hc, *m_n);

      output.push_back(MpzTool::Mpz_to_string(hc));
    }
  Memreuse::Delete(hc);
  return 0;
}

int BRSA_PSI_Client::OnResponse1(const vector<string>& input)
{
  m_vecResult.clear();
  mpz_t * yi = Memreuse::New();
  size_t i = 0;
  for (i = 0; i < m_set.size(); i++)
    {
      MpzTool::Mpz_from_string(yi, input[i]);
      mpz_mul(*yi, *yi, *m_vecRinv[i]);
      mpz_mod(*yi, *yi, *m_n);
      m_mapTp[CryptoTool::Hash(yi)] = i;
    }
  if (!m_adaptive)
	{
	  map<string,size_t>::iterator it;
	  for (; i < input.size(); i++)
		{
		  if ((it = m_mapTp.find(input[i])) != m_mapTp.end())
			{
			  m_vecResult.push_back(it->second);
			}
		}
	}
  else
	{
	  map<string, size_t>::iterator it;
	  for (size_t i = 0; i < m_data.size(); i++)
		{
		  if ((it = m_mapTp.find(m_data[i])) != m_mapTp.end())
			{
			  m_vecResult.push_back(it->second);
			}
		}
	}
  return 0;
}

