#include "base.h"
#include "crypto_tool.h"

int main(int argc, char * argv[])
{
  FILE * privfile = fopen("elgamal.1024.priv", "w+");
  FILE * pubfile = fopen("elgamal.1024.pub", "w+");
  mpz_t * g, *p, *q, *x, *h;
  g = Memreuse::New();
  p = Memreuse::New();
  q = Memreuse::New();
  x = Memreuse::New();
  h = Memreuse::New();
  int nbits = 1024;
  if (argc == 2)
	{
	  nbits = atoi(argv[1]);
	}
  CryptoTool::GenerateCyclicGroup(g, p, q, x, h, nbits);
  gmp_fprintf(privfile, "%Zx\n", *g);
  gmp_fprintf(privfile, "%Zx\n", *p);
  gmp_fprintf(privfile, "%Zx\n", *q);
  gmp_fprintf(privfile, "%Zx\n", *x);
  gmp_fprintf(privfile, "%Zx\n", *h);

  gmp_fprintf(pubfile, "%Zx\n", *g);
  gmp_fprintf(pubfile, "%Zx\n", *p);
  gmp_fprintf(pubfile, "%Zx\n", *q);
  gmp_fprintf(pubfile, "%Zx\n", *h);

  fclose(pubfile);
  fclose(privfile);
  return 0;
}
