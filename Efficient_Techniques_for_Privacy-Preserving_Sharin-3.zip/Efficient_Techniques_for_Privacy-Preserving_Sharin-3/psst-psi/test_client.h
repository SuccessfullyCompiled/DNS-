#ifndef TEST_CLIENT_H
#define TEST_CLIENT_H

#include "client.h"

class TestClient: public Client
{
 public:
  TestClient();
  virtual void Initialize();
  /* first round of request, output will be sent to the server */
  virtual int Request1(vector<string>& output);
  /* second round of request, output will be sent to the server */
  virtual int Request2(vector<string>& output);
  /* action after first round of response from server */
  virtual int OnResponse1(const vector<string>& input);
  /* action after second round of response from server */
  virtual int OnResponse2(const vector<string>& input);
};

#endif
