/* ---------------------------------------------------------------------
 *
 * -- Privacy-preserving Sharing of Sensitive information Toolkit (PSST)
 *    (C) Copyright 2010 All Rights Reserved
 *
 * -- PSST routines -- Version 1.0.1 -- April, 2010
 * BRSA corresponds to protocol DT10-2 in the paper
 *
 * Author         : Yanbin Lu
 * Security and Privacy Research Outfit (SPROUT),
 * University of California, Irvine
 *
 * -- Bug report: send email to yanbinl@uci.edu
 * ---------------------------------------------------------------------
 *
 * -- Copyright notice and Licensing terms:
 *
 *  Redistribution  and  use in  source and binary forms, with or without
 *  modification, are  permitted provided  that the following  conditions
 *  are met:
 *
 * 1. Redistributions  of  source  code  must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce  the above copyright
 *    notice,  this list of conditions, and the  following disclaimer in
 *    the documentation and/or other materials provided with the distri-
 *    bution.
 * 3. The name of the University,  the SPROUT group,  or the names of its
 *    authors  may not be used to endorse or promote products deri-
 *    ved from this software without specific written permission.
 *
 * -- Disclaimer:
 *
 * THIS  SOFTWARE  IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,  INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE UNIVERSITY
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,  INDIRECT, INCIDENTAL, SPE-
 * CIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO,  PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEO-
 * RY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT  (IN-
 * CLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "brsa_psi_server.h"
#include "crypto_tool.h"
#include "basic_tool.h"
#include "mpz_tool.h"

BRSA_PSI_Server::BRSA_PSI_Server()
{
  m_n = Memreuse::New();
  m_rsa = new RSA_struct;
}

void BRSA_PSI_Server::LoadData()
{
  m_set.clear();
  m_rawset.clear();

  ifstream infile(m_strInputFile.c_str());
  if (!infile)
	{
	  cerr<<"open "<<m_strInputFile<<" error"<<endl;
	  return;
	}
  string element;
  while (getline(infile, element) && infile.good())
	{
	  m_rawset.push_back(element);
	  mpz_t * e = Memreuse::New();
	  CryptoTool::FDH(e, element, m_n);
	  m_set.push_back(e);
	}
}

void BRSA_PSI_Server::Setup(int nbits)
{
  stringstream keyfile;
  keyfile<<"rsa."<<nbits<<".priv";

  BasicTool::Load_RSA_Priv_Key(keyfile.str(), m_rsa);
  m_n = m_rsa->n;
  LoadData();

  rn.Initialize(nbits);
}

void BRSA_PSI_Server::Initialize(int nbits)
{
  for (size_t i = 0; i < m_set.size(); i++)
    {
      mpz_t * k = Memreuse::New();
	  CryptoTool::RsaSig(k, m_set[i], m_rsa);
//       mpz_powm(*k, *m_set[i], *(m_rsa->d), *(m_rsa->n));
// 	  gmp_printf("k=%Zx\n", *k);

	  m_toutput.push_back(CryptoTool::Hash(k));
	}
}

void BRSA_PSI_Server::PublishData(vector<string>& output)
{
  if (m_adaptive)
	output.insert(output.end(), m_toutput.begin(), m_toutput.end());
}

int BRSA_PSI_Server::OnRequest1(const vector<string>& input)
{
  mpz_t * yi = Memreuse::New();

  for (size_t i = 0; i < input.size(); i++)
	{
	  MpzTool::Mpz_from_string(yi, input[i]);
	  //mpz_powm(*yi, *yi, *m_x, *m_n);
	  CryptoTool::RsaSig(yi, yi, m_rsa);
	  m_output.push_back(MpzTool::Mpz_to_string(yi));
	}
  if (!m_adaptive)
	m_output.insert(m_output.end(), m_toutput.begin(), m_toutput.end());

  Memreuse::Delete(yi);
  return 0;
}
