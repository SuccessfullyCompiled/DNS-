#ifndef CONFIG_H
#define CONFIG_H

#include "base.h"

class Config
{
 public:
  static int    Input(string filename);
 public:
  static string m_protocol;
};


#endif
