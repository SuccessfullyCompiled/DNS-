/* ---------------------------------------------------------------------
 *
 * -- Privacy-preserving Sharing of Sensitive information Toolkit (PSST)
 *    (C) Copyright 2010 All Rights Reserved
 *
 * -- PSST routines -- Version 1.0.1 -- April, 2010
 * RSA_PSI_OPT corresponds to protocol DT10-1 in the paper
 *
 * Author         : Yanbin Lu
 * Security and Privacy Research Outfit (SPROUT),
 * University of California, Irvine
 *
 * -- Bug report: send email to yanbinl@uci.edu
 * ---------------------------------------------------------------------
 *
 * -- Copyright notice and Licensing terms:
 *
 *  Redistribution  and  use in  source and binary forms, with or without
 *  modification, are  permitted provided  that the following  conditions
 *  are met:
 *
 * 1. Redistributions  of  source  code  must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce  the above copyright
 *    notice,  this list of conditions, and the  following disclaimer in
 *    the documentation and/or other materials provided with the distri-
 *    bution.
 * 3. The name of the University,  the SPROUT group,  or the names of its
 *    authors  may not be used to endorse or promote products deri-
 *    ved from this software without specific written permission.
 *
 * -- Disclaimer:
 *
 * THIS  SOFTWARE  IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,  INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE UNIVERSITY
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,  INDIRECT, INCIDENTAL, SPE-
 * CIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO,  PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEO-
 * RY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT  (IN-
 * CLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "rsa_psi_opt_server.h"
#include "crypto_tool.h"
#include "basic_tool.h"
#include "mpz_tool.h"

RSA_PSI_OPT_Server::RSA_PSI_OPT_Server()
{
  m_p = Memreuse::New();
  m_g = Memreuse::New();
  m_q = Memreuse::New();
  m_y = Memreuse::New();
  m_Z = Memreuse::New();
  m_Rs = Memreuse::New();
}

void RSA_PSI_OPT_Server::LoadData()
{
  m_set.clear();
  m_rawset.clear();

  ifstream infile(m_strInputFile.c_str());
  if (!infile)
	{
	  cerr<<"open "<<m_strInputFile<<" error"<<endl;
	  return;
	}
  string element;
  while (getline(infile, element) && infile.good())
	{
	  m_rawset.push_back(element);
	  mpz_t * e = Memreuse::New();
	  CryptoTool::FDH(e, element, m_p);
	  m_set.push_back(e);
	}
}

void RSA_PSI_OPT_Server::Setup(int nbits)
{
  stringstream keyfile;
  keyfile<<"dsa."<<nbits<<".pub";
  BasicTool::Load_DSA_Pub_Key(m_p, m_q, m_g, m_y, keyfile.str());
  LoadData();
  rn.Initialize(nbits);
}

void RSA_PSI_OPT_Server::Initialize(int nbits)
{
  rn.Get_Z_Range(m_Rs, m_q);
  mpz_powm(*m_Z, *m_g, *m_Rs, *m_p);
  for (size_t i = 0; i < m_set.size(); i++)
	{
	  mpz_t * inv2r = Memreuse::New();
	  mpz_invert(*inv2r, *m_set[i], *m_p);
	  mpz_powm(*inv2r, *inv2r, *m_Rs, *m_p);
	  m_invHs2R.push_back(inv2r);
	}
}

int RSA_PSI_OPT_Server::OnRequest1(const vector<string>& input)
{
  m_output.clear();
  mpz_t * Ksj = Memreuse::New();
  mpz_t * X = Memreuse::New();
  MpzTool::Mpz_from_string(X, input[0]);
  
  m_output.push_back(MpzTool::Mpz_to_string(m_Z));

  mpz_t * yi = Memreuse::New();
  for (size_t i = 1; i < input.size(); i++)
	{
	  MpzTool::Mpz_from_string(yi, input[i]);

	  mpz_powm(*yi, *yi, *m_Rs, *m_p);
	  m_output.push_back(MpzTool::Mpz_to_string(yi));
	}
  mpz_powm(*X, *X, *m_Rs, *m_p);
  for (size_t i = 0; i < m_set.size(); i++)
	{
	  mpz_mul(*Ksj, *X, *m_invHs2R[i]);
	  mpz_mod(*Ksj, *Ksj, *m_p);
	  m_output.push_back(CryptoTool::Hash(Ksj));
	}
  return 0;
}
